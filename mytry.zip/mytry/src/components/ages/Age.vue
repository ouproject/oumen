<template>
    <div>年龄</div>
</template>

<script>
    export default {
        name: "Age"
    }
</script>

<style scoped>

</style>
