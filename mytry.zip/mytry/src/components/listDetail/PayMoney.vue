<template>
    <div>支付订单</div>
</template>

<script>
    export default {
        name: "PayMoney"
    }
</script>

<style scoped>

</style>
