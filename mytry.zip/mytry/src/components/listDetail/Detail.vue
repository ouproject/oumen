<template>
    <div>详情页</div>
</template>

<script>
    export default {
        name: "Detail"
    }
</script>

<style scoped>

</style>
